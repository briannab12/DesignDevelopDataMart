SELECT * FROM product;

UPDATE product SET name='Automobile Fillers CHANGED' WHERE productSK=3;

SELECT * FROM product;

