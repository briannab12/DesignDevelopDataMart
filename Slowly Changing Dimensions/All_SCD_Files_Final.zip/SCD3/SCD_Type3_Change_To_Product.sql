USE dw171_salesorders_scd3;

SELECT * FROM product;

ALTER TABLE product CHANGE `name` `preivousName` VARCHAR(45);

ALTER TABLE product ADD newName VARCHAR(45);

INSERT INTO product (ProductSK, ProdID, preivousName, price1, price2, prodTypeID, typeDescription, BUID, BUIDname, BUIDabbrev, saleBy, newName) 
VALUES(898, 25, 'Automobiles Fillers', 283.83, 227.63, NULL, 'Fillers', 'C', 'Chemicals','Chemicals', NULL, 'CAR FILLERS CHANGED');

SELECT * FROM product;