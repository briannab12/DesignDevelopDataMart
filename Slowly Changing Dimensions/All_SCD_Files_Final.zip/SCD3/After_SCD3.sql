CREATE DATABASE  IF NOT EXISTS `dw171_salesorders_scd3` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `dw171_salesorders_scd3`;
-- MySQL dump 10.13  Distrib 5.7.12, for Win64 (x86_64)
--
-- Host: localhost    Database: dw171_salesorders_scd3
-- ------------------------------------------------------
-- Server version	5.7.18-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `customer`
--

DROP TABLE IF EXISTS `customer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer` (
  `customerSK` int(11) NOT NULL DEFAULT '0',
  `custTypeID` char(1) DEFAULT NULL,
  `customerID` tinyint(4) DEFAULT NULL,
  `typeName` varchar(20) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `addr1` varchar(50) DEFAULT NULL,
  `addr2` varchar(50) DEFAULT NULL,
  `city` varchar(20) DEFAULT NULL,
  `state` char(2) DEFAULT NULL,
  `zip` char(5) DEFAULT NULL,
  PRIMARY KEY (`customerSK`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer`
--

LOCK TABLES `customer` WRITE;
/*!40000 ALTER TABLE `customer` DISABLE KEYS */;
/*!40000 ALTER TABLE `customer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dates`
--

DROP TABLE IF EXISTS `dates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dates` (
  `dateSK` int(11) NOT NULL AUTO_INCREMENT,
  `day` varchar(45) DEFAULT NULL,
  `year` varchar(45) DEFAULT NULL,
  `quarter` varchar(45) DEFAULT NULL,
  `month` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`dateSK`)
) ENGINE=InnoDB AUTO_INCREMENT=2132 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dates`
--

LOCK TABLES `dates` WRITE;
/*!40000 ALTER TABLE `dates` DISABLE KEYS */;
/*!40000 ALTER TABLE `dates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `manufacturing_cost`
--

DROP TABLE IF EXISTS `manufacturing_cost`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `manufacturing_cost` (
  `manufacturingCostSK` int(11) NOT NULL DEFAULT '0',
  `prodID` int(11) DEFAULT NULL,
  `year` varchar(45) DEFAULT NULL,
  `month` varchar(45) DEFAULT NULL,
  `manufacturingCost` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`manufacturingCostSK`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `manufacturing_cost`
--

LOCK TABLES `manufacturing_cost` WRITE;
/*!40000 ALTER TABLE `manufacturing_cost` DISABLE KEYS */;
/*!40000 ALTER TABLE `manufacturing_cost` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_date`
--

DROP TABLE IF EXISTS `order_date`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order_date` (
  `orderDateSK` int(11) NOT NULL AUTO_INCREMENT,
  `day` varchar(45) DEFAULT NULL,
  `year` varchar(45) DEFAULT NULL,
  `quarter` varchar(45) DEFAULT NULL,
  `month` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`orderDateSK`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_date`
--

LOCK TABLES `order_date` WRITE;
/*!40000 ALTER TABLE `order_date` DISABLE KEYS */;
/*!40000 ALTER TABLE `order_date` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product`
--

DROP TABLE IF EXISTS `product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product` (
  `productSK` int(11) NOT NULL DEFAULT '0',
  `prodID` int(11) DEFAULT NULL,
  `preivousName` varchar(45) DEFAULT NULL,
  `price1` decimal(10,2) DEFAULT NULL,
  `price2` decimal(10,2) DEFAULT NULL,
  `prodTypeID` int(11) DEFAULT NULL,
  `typeDescription` varchar(25) DEFAULT NULL,
  `BUID` char(1) DEFAULT NULL,
  `BUIDname` varchar(25) DEFAULT NULL,
  `BUIDabbrev` varchar(10) DEFAULT NULL,
  `saleBy` varchar(45) DEFAULT NULL,
  `newName` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`productSK`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product`
--

LOCK TABLES `product` WRITE;
/*!40000 ALTER TABLE `product` DISABLE KEYS */;
INSERT INTO `product` VALUES (3,25,'Automobiles Fillers',283.83,227.63,NULL,'Fillers','D','Miscellaneous','Misc',NULL,NULL),(5,98,'Barrels Flushing Chemicals',135.10,116.59,NULL,'Flushing Chemicals','C','Chemicals','Chemicals',NULL,NULL),(7,94,'Beliefs Freezing Chemicals',566.64,483.91,NULL,'Freezing Chemicals','C','Chemicals','Chemicals',NULL,NULL),(9,64,'Berwick Fillers',583.85,487.51,NULL,'Fillers','D','Miscellaneous','Misc',NULL,NULL),(11,43,'Blazed Covers',495.00,416.79,NULL,'Covers','D','Miscellaneous','Misc',NULL,NULL),(12,29,'Bluest Fillers',507.35,428.20,NULL,'Fillers','D','Miscellaneous','Misc',NULL,NULL),(15,42,'Carelessly Freezing Chemicals',559.67,467.88,NULL,'Freezing Chemicals','C','Chemicals','Chemicals',NULL,NULL),(20,38,'Commendation Fillers',436.33,380.04,NULL,'Fillers','D','Miscellaneous','Misc',NULL,NULL),(24,73,'Cosgrove Jacks',298.87,267.79,NULL,'Jacks','D','Miscellaneous','Misc',NULL,NULL),(27,13,'Coward Covers',429.79,348.99,NULL,'Covers','D','Miscellaneous','Misc',NULL,NULL),(31,75,'Deferrable Freezing Chemicals',145.03,124.44,NULL,'Freezing Chemicals','C','Chemicals','Chemicals',NULL,NULL),(33,30,'Detectives Jacks',283.32,248.47,NULL,'Jacks','D','Miscellaneous','Misc',NULL,NULL),(35,15,'Disposed Fillers',158.84,138.03,NULL,'Fillers','D','Miscellaneous','Misc',NULL,NULL),(40,14,'Engle Photo Chemicals',429.94,346.10,NULL,'Photo Chemicals','C','Chemicals','Chemicals',NULL,NULL),(41,16,'Enhanced Covers',460.96,384.44,NULL,'Covers','D','Miscellaneous','Misc',NULL,NULL),(45,66,'Exemplar Freezing Chemicals',198.40,160.90,NULL,'Freezing Chemicals','C','Chemicals','Chemicals',NULL,NULL),(48,74,'Flanker Fillers',271.44,236.15,NULL,'Fillers','D','Miscellaneous','Misc',NULL,NULL),(50,19,'Hesitating Jacks',124.46,100.07,NULL,'Jacks','D','Miscellaneous','Misc',NULL,NULL),(52,54,'Honeymoon Photo Chemicals',326.13,292.21,NULL,'Photo Chemicals','C','Chemicals','Chemicals',NULL,NULL),(53,83,'Horses Lifts',487.30,402.51,NULL,'Lifts','D','Miscellaneous','Misc',NULL,NULL),(54,52,'Identical Freezing Chemicals',578.07,465.92,NULL,'Freezing Chemicals','C','Chemicals','Chemicals',NULL,NULL),(57,104,'LCARS Covers',289.41,231.42,NULL,'Covers','D','Miscellaneous','Misc',NULL,NULL),(59,78,'Measured Photo Chemicals',318.06,270.67,NULL,'Photo Chemicals','C','Chemicals','Chemicals',NULL,NULL),(60,102,'Measured Photo Chemicals',318.06,270.67,NULL,'Photo Chemicals','C','Chemicals','Chemicals',NULL,NULL),(61,29,'Millimeters Flushing Chemicals',295.56,251.82,NULL,'Flushing Chemicals','C','Chemicals','Chemicals',NULL,NULL),(63,82,'Numerals Covers',102.87,88.98,NULL,'Covers','D','Miscellaneous','Misc',NULL,NULL),(74,51,'Reflection Lifts',497.85,447.57,NULL,'Lifts','D','Miscellaneous','Misc',NULL,NULL),(76,99,'Richards Freezing Chemicals',529.35,475.36,NULL,'Freezing Chemicals','C','Chemicals','Chemicals',NULL,NULL),(77,53,'Ruffle Freezing Chemicals',476.38,394.92,NULL,'Freezing Chemicals','C','Chemicals','Chemicals',NULL,NULL),(80,76,'Scrounge Jacks',301.58,251.22,NULL,'Jacks','D','Miscellaneous','Misc',NULL,NULL),(83,47,'Significants Freezing Chemicals',141.55,113.24,NULL,'Freezing Chemicals','C','Chemicals','Chemicals',NULL,NULL),(86,45,'Slacking Jacks',495.04,399.99,NULL,'Jacks','D','Miscellaneous','Misc',NULL,NULL),(87,17,'Sortie Covers',248.21,213.21,NULL,'Covers','D','Miscellaneous','Misc',NULL,NULL),(92,62,'Substances Flushing Chemicals',507.34,409.93,NULL,'Flushing Chemicals','C','Chemicals','Chemicals',NULL,NULL),(94,41,'Sulkiness Covers',354.30,289.82,NULL,'Covers','D','Miscellaneous','Misc',NULL,NULL),(96,3,'Tailor Jacks',509.78,429.74,NULL,'Jacks','D','Miscellaneous','Misc',NULL,NULL),(100,14,'Travelings Photo Chemicals',274.39,242.01,NULL,'Fillers','D','Miscellaneous','Misc',NULL,NULL),(104,49,'Visage Flushing Chemicals',567.75,507.57,NULL,'Flushing Chemicals','C','Chemicals','Chemicals',NULL,NULL),(106,103,'Whale Lifts',493.40,406.78,NULL,'Lifts','D','Miscellaneous','Misc',NULL,NULL),(107,22,'Whippers Covers',488.61,410.43,NULL,'Covers','D','Miscellaneous','Misc',NULL,NULL),(108,28,'Wonderingly Covers',547.21,467.32,NULL,'Covers','D','Miscellaneous','Misc',NULL,NULL),(898,25,'Automobiles Fillers',283.83,227.63,NULL,'Fillers','C','Chemicals','Chemicals',NULL,'CAR FILLERS CHANGED');
/*!40000 ALTER TABLE `product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sale_details`
--

DROP TABLE IF EXISTS `sale_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sale_details` (
  `sale_details_sk` int(11) NOT NULL DEFAULT '0',
  `shipping_method` varchar(45) DEFAULT NULL,
  `order_method` varchar(45) DEFAULT NULL,
  `payment_method` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`sale_details_sk`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sale_details`
--

LOCK TABLES `sale_details` WRITE;
/*!40000 ALTER TABLE `sale_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `sale_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sales_date`
--

DROP TABLE IF EXISTS `sales_date`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sales_date` (
  `salesDateSK` int(11) NOT NULL AUTO_INCREMENT,
  `day` varchar(45) DEFAULT NULL,
  `year` varchar(45) DEFAULT NULL,
  `quarter` varchar(45) DEFAULT NULL,
  `month` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`salesDateSK`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sales_date`
--

LOCK TABLES `sales_date` WRITE;
/*!40000 ALTER TABLE `sales_date` DISABLE KEYS */;
/*!40000 ALTER TABLE `sales_date` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sales_fact`
--

DROP TABLE IF EXISTS `sales_fact`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sales_fact` (
  `productSK_FK` int(11) NOT NULL DEFAULT '1',
  `customerSK_FK` int(11) NOT NULL DEFAULT '1',
  `supplierSK_FK` int(11) NOT NULL DEFAULT '1',
  `salesDateSK_FK` int(11) NOT NULL DEFAULT '1',
  `orderDateSK_FK` int(11) NOT NULL DEFAULT '1',
  `saleDetailsSK_FK` int(11) NOT NULL DEFAULT '1',
  `manufacturingCostSK_FK` int(11) NOT NULL,
  `amount` decimal(10,2) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `discounted` tinyint(4) DEFAULT NULL,
  `invoiceProcessingDays` int(11) DEFAULT NULL,
  `invoiceID` int(11) DEFAULT NULL,
  `invoiceDepartment` varchar(45) DEFAULT NULL,
  `internalSale` tinyint(4) DEFAULT NULL,
  `unitCost` decimal(10,2) DEFAULT NULL,
  `shippingCost` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`productSK_FK`,`customerSK_FK`,`supplierSK_FK`,`salesDateSK_FK`,`orderDateSK_FK`,`saleDetailsSK_FK`,`manufacturingCostSK_FK`),
  KEY `customerSK_idx` (`customerSK_FK`),
  KEY `supplierSK_idx` (`supplierSK_FK`),
  KEY `saleDetails_idx` (`saleDetailsSK_FK`),
  KEY `fk_SALES_FACT_MANUFACTURING_DATE1_idx` (`manufacturingCostSK_FK`),
  KEY `salesDateSK_idx` (`salesDateSK_FK`),
  KEY `orderDateSK_idx` (`orderDateSK_FK`),
  CONSTRAINT `customerSK` FOREIGN KEY (`customerSK_FK`) REFERENCES `customer` (`customerSK`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_SALES_FACT_MANUFACTURING_DATE1` FOREIGN KEY (`manufacturingCostSK_FK`) REFERENCES `manufacturing_cost` (`manufacturingCostSK`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `orderDateSK` FOREIGN KEY (`orderDateSK_FK`) REFERENCES `dates` (`dateSK`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `productSK` FOREIGN KEY (`productSK_FK`) REFERENCES `product` (`productSK`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `saleDetails` FOREIGN KEY (`saleDetailsSK_FK`) REFERENCES `sale_details` (`sale_details_sk`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `salesDateSK` FOREIGN KEY (`salesDateSK_FK`) REFERENCES `dates` (`dateSK`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `supplierSK` FOREIGN KEY (`supplierSK_FK`) REFERENCES `supplier` (`supplierSK`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sales_fact`
--

LOCK TABLES `sales_fact` WRITE;
/*!40000 ALTER TABLE `sales_fact` DISABLE KEYS */;
/*!40000 ALTER TABLE `sales_fact` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `supplier`
--

DROP TABLE IF EXISTS `supplier`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `supplier` (
  `supplierSK` int(11) NOT NULL DEFAULT '0',
  `name` varchar(50) DEFAULT NULL,
  `addr1` varchar(50) DEFAULT NULL,
  `addr2` varchar(50) DEFAULT NULL,
  `city` varchar(20) DEFAULT NULL,
  `state` char(2) DEFAULT NULL,
  `zip` char(5) DEFAULT NULL,
  PRIMARY KEY (`supplierSK`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `supplier`
--

LOCK TABLES `supplier` WRITE;
/*!40000 ALTER TABLE `supplier` DISABLE KEYS */;
/*!40000 ALTER TABLE `supplier` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-12-10 13:59:16
