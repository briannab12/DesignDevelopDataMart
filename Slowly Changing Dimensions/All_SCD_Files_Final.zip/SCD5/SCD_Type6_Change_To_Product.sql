USE dw171_salesorders_scd5;

SELECT * FROM product;

#ALTER TABLE product CHANGE `price1` `previousPrice1` DECIMAL(10,2);

#ALTER TABLE product ADD newPrice1 DECIMAL(10,2);

INSERT INTO product (ProductSK, ProdID, name, previousPrice1, price2, prodTypeID, typeDescription, BUID, BUIDname, BUIDabbrev, saleBy, newPrice1) 
VALUES(942, 25, 'Automobiles Fillers', 283.83, 227.63, NULL, 'Fillers', 'B', 'Miscellaneous','Misc', NULL, 283.83);

INSERT INTO product (ProductSK, ProdID, name, previousPrice1, price2, prodTypeID, typeDescription, BUID, BUIDname, BUIDabbrev, saleBy, newPrice1) 
VALUES(987, 25, 'Automobiles Fillers', 283.83, 227.63, NULL, 'Fillers', 'B', 'Miscellaneous','Misc', NULL, 300.99);

SELECT * FROM product;