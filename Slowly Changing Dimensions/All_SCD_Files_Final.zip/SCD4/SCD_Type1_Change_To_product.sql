USE dw171_salesorders_scd4;

SELECT * FROM product;

UPDATE product SET prodID=420 WHERE productSK=3;

SELECT * FROM product;