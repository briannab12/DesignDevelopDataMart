USE dw171_salesorders_scd2;

SELECT * FROM product;

INSERT INTO product (ProductSK, ProdID, name, price1, price2, prodTypeID, typeDescription, BUID, BUIDname, BUIDabbrev, saleBy) 
VALUES(999, 25, 'Automobiles Fillers', 283.83, 227.63, NULL, 'Fillers', 'C', 'Chemicals','Chemicals', NULL);

SELECT * FROM product;